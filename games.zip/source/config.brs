function GetBackendBaseUrl() as String
    ' Set this to your backend server, e.g. http://192.168.1.50:8787
    return "http://192.168.1.29:8787"
end function

function GetDashboardTimezone() as String
    return "America/Chicago"
end function
